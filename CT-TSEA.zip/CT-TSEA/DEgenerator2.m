function [Offspring] = DEgenerator2(Problem,Population,avg_change)


    cv = sum(max(0,Population.cons),2);       

    FrontNo = NDSort(Population.objs,Population.cons,1);   
    index1  = find(FrontNo==1);
    r       = floor(rand*length(index1))+1;
    best    = index1(r);

    [N,D] = size(Population(1).decs);       
    trial = zeros(1*Problem.N,D);
    F = 0.5;  % 初始缩放因子
   CR = 0.8;  % 初始交叉概率
   threshold = 0;  % 变化阈值，可以根据需要调整    

    for i = 1 : Problem.N   
        if avg_change > threshold
            F = F * (1 + sign(avg_change) * abs(avg_change));
            CR = CR * (1 - sign(avg_change) * abs(avg_change));
            indexset    = 1 : Problem.N;
            indexset(i) = [];
            r1  = floor(rand*(Problem.N-1))+1;
            xr1 = indexset(r1);
            indexset(r1) = [];
            r2  = floor(rand*(Problem.N-2))+1;
            xr2 = indexset(r2)  ;
            r3  = floor(rand*(Problem.N-3))+1;
            xr3 = indexset(r3);
            Best_index = Population(best).decs;
            v      = Population(xr1).decs+rand*(Best_index-Population(xr1).decs)+F *(Population(xr2).decs-Population(xr3).decs);  
            Lower  = repmat(Problem.lower,N,1);
            Upper  = repmat(Problem.upper,N,1);
            v      = min(max(v,Lower),Upper);
            Site   = rand(N,D) < CR;
            j_rand = floor(rand * D) + 1;
            Site(1, j_rand) = 1;
            Site_  = 1-Site;
            trial(i, :) = Site.*v+Site_.*Population(i).decs;  

        else
            F = F * (1 + sign(avg_change) * abs(avg_change));
            CR = CR * (1 - sign(avg_change) * abs(avg_change));
%             indexset    = 1:Problem.N;
%             indexset(i) = [];
%             r1  = floor(rand*(Problem.N-1))+1;
%             xr1 = indexset(r1);
%             indexset(r1) = [];
%             r2  = floor(rand*(Problem.N-2))+1;
%             xr2 = indexset(r2);
%             indexset(r2) = [];
%             r3    = floor(rand*(Problem.N-3))+1;
%             xr3   = indexset(r3);
%             v     = Population(i).decs+rand*(Population(xr1).decs-Population(i).decs)+F*(Population(xr2).decs-Population(xr3).decs); 
%             Lower = repmat(Problem.lower,N,1);
%             Upper = repmat(Problem.upper,N,1); 
%             trial(i, :) = min(max(v,Lower),Upper);   
            indexset    = 1 : Problem.N;
            indexset(i) = [];
            r1  = floor(rand*(Problem.N-1))+1;
            xr1 = indexset(r1);
            indexset(r1) = [];
            r2  = floor(rand*(Problem.N-2))+1;
            xr2 = indexset(r2)  ;
            r3  = floor(rand*(Problem.N-3))+1;
            xr3 = indexset(r3);
            Best_index = Population(best).decs;
            v      = Population(xr1).decs+rand*(Best_index-Population(xr1).decs)+F *(Population(xr2).decs-Population(xr3).decs);  
            Lower  = repmat(Problem.lower,N,1);
            Upper  = repmat(Problem.upper,N,1);
            v      = min(max(v,Lower),Upper);
            Site   = rand(N,D) < CR;
            j_rand = floor(rand * D) + 1;
            Site(1, j_rand) = 1;
            Site_  = 1-Site;
            trial(i, :) = Site.*v+Site_.*Population(i).decs;  
        end
    end
    Offspring = trial;
    Offspring = Problem.Evaluation(Offspring);
end