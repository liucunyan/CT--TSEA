classdef CT_TSEA < ALGORITHM
    methods
        function main(Algorithm,Problem)
            %% Generate the sampling points and random population
            Population = Problem.Initialization();
            CV = sum(max(0,Population.cons),2);
            W = UniformPoint(Problem.N,Problem.M);
            Archive = Population(CV==0);
            stage_conver = 0;
            avg_change=0.0000001;
            numIterations = ceil(Problem.maxFE / Problem.N);  
            epsnArray = zeros(numIterations, 1);  
            iterationCount = 1;  
            %% Optimization
            while Algorithm.NotTerminated(Population)
                if Problem.FE<0.5*Problem.maxFE  % 当前函数评估次数 FE 小于总评估次数 maxFE 的一半
                    z          = min(Population.objs,[],1);
                    Fitness    = CalFitness(Population.objs,Population.cons);
                    a          = 0.5*(1-cos((1-Problem.FE/Problem.maxFE)*pi));
                    avg_fit     = sum(max(abs((Population.objs-repmat(z,Problem.N,1)).*a),[],2))/Problem.N;
                    epsilon_max = max(sum(max(Population.cons,0),2));
                    epsilon     = epsilon_max*size(Population.cons,2);
                    sigma = max(avg_fit,epsilon);                  
                    epsn       = ReduceBoundary(sigma, ceil(Problem.FE/Problem.N), ceil(Problem.maxFE/Problem.N)-1);
                    epsnArray(iterationCount) = epsn;
                    iterationCount = iterationCount + 1;
                    Population1=[Population,Archive];
                    MatingPool = [Population1(randsample(Problem.N,Problem.N))];
                    [Mate1,Mate2,Mate3]  = Neighbor_Pairing_Strategy(MatingPool, z);
                    Offspring(1:Problem.N/2) = OperatorDE_rand_1(Problem,Mate1(1:Problem.N/2), Mate2(1:Problem.N/2), Mate3(1:Problem.N/2));
                    Offspring(1+Problem.N/2:Problem.N) = OperatorDE_pbest_1_main(Population, Problem.N/2, Problem, Fitness, 0.1);
                    Archive = UpdateArchive(Archive,[Population,Offspring],Problem.N);       
                    [Population ,~] = EnvironmentalSelection2([Population, Offspring], Problem.N,epsn, [Population.cons-epsn; Offspring.cons-epsn]);
                    else
                    if stage_conver==0
                       temp = Population;
                        Population = Archive;
                        Archive = temp;
                        stage_conver = 1;
                    end
                    ratio=0.5;
                    previous = mean([Population.objs]);
                    MatingPool = MatingSelectionElite(Population,Archive,Problem.N,ratio);
                    Offspring = DEgenerator2(Problem,MatingPool,avg_change);
                    Archive = UpdateArchive(Archive,[Population,Offspring],Problem.N);
                    Population = EnvironmentalSelectionElite([Population,Offspring],Problem.N);
                    current = mean([Population.objs]);
                    avg_change = current(2) - previous(2);  
                end
            end
        end
    end
end


function epsn = ReduceBoundary(eF, k, MaxK)
    z        = 1e-8;
    Nearzero = 1e-15;
     B        = MaxK;
    B(B==0)  = B(B==0) + Nearzero;
      f        = eF.* exp( -(2*k./B).^10 );
    tmp      = find(abs(f-z) < Nearzero);
    f(tmp)   = f(tmp).*0 + z;
    epsn     = f - z;

end 