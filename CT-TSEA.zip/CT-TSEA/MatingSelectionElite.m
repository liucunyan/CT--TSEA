function MatingPool = MatingSelectionElite(TargetPop,SourcePop,N,ratio)

 MatingPool = [];
 
if length(SourcePop)<N ||sum(sum(max(0,TargetPop.cons),2)==0)<N  %当SourcePo不满足N个解时，将TargetPop,SourcePop种群合并
                                                                 %根据密度的降序排序，采用二元锦标赛的方法选取优质解进行补充
    PopAll = [TargetPop,SourcePop];
    [~,b]=unique(PopAll.objs,'rows');
    PopAll = PopAll(1,b);
    SelectedIndex= TournamentSelection(2,N,DensityCal(PopAll.decs));
    MatingPool= PopAll(SelectedIndex);
else                                                              %当SourcePo>N个解时，计算出TargetPop和SourcePop的目标值和密度值
                                                                  %根据以下规则进行淘汰劣质解
    Density1 =  DensityCal(TargetPop.objs);
    Density2 =  DensityCal(SourcePop.objs);
    index1 = randi(N,1,N);
    index2 = randi(N,1,N);
    for i = 1:N 
        PopObj1 = TargetPop.objs;
        PopObj2 = SourcePop.objs; 
       
        CV = sum(max(0,SourcePop.cons),2)==0;
        
        if rand < ratio %表示等概率选取的意思
          if  PopObj1(index1(i),:)<PopObj1(index2(i),:)
            MatingPool = [MatingPool, TargetPop(index1(i))];
          elseif  PopObj1(index1(i),:)>PopObj1(index2(i),:)
             MatingPool = [MatingPool, TargetPop(index2(i))];
          elseif Density1(index1(i)) < Density1(index2(i))
             MatingPool = [MatingPool, TargetPop(index1(i))];
          else
             MatingPool = [MatingPool, TargetPop(index2(i))];
          end
        else  
            if min(PopObj2(index1(i),:)<PopObj2(index2(i),:))==1 || min(PopObj2(index1(i),:)>PopObj2(index2(i),:))==1
                if CV(index1(i),:)< CV(index2(i),:)
                 MatingPool = [MatingPool, SourcePop(index1(i))];
                else
                 MatingPool = [MatingPool, SourcePop(index2(i))];    
                end
            elseif Density2(index1(i)) < Density2(index2(i))
                MatingPool = [MatingPool, SourcePop(index1(i))];
            else
                 MatingPool = [MatingPool, SourcePop(index2(i))];   
            end
            
        end
        
    end       
end
end  
 %在等概率判断中，确定TargetPop和SourcePop选解，当rand<ratio，在TargetPop根据目标值和密度值进行选取优质解
 %                                              当rand<ratio，在SourcePop根据约束违反度值和密度值进行选取优质解
 function Density = DensityCal(PopObj)
     [N,~] = size(PopObj);  %获取矩阵 PopObj 的行数存储在变量 N 中，而列数则被忽略。
    Zmin       = min(PopObj,[],1);%计算每列的最小值，将结果存储在向量 Zmin 中。这是为了后续的归一化操作。
    PopObj = (PopObj-repmat(Zmin,N,1))./(repmat(max(PopObj),N,1)-repmat(Zmin,N,1)+1e-20);
    %将目标函数值进行归一化操作，确保它们都在 [0, 1] 范围内。这样做是为了在计算密度时考虑到目标函数值的相对大小。
    Distance = pdist2(PopObj,PopObj);%计算归一化后的目标函数值之间的欧几里德距离矩阵 Distance。
    Distance(logical(eye(length(Distance)))) = Inf;
    %将距离矩阵对角线上的元素（同一个解与自身的距离）设置为无穷大，以排除解与自身的距离。
    DistanceSort = sort(Distance,2);%对每行的距离值进行排序，得到排序后的距离矩阵 DistanceSort。
    Density = 1./(1+DistanceSort(:,floor(sqrt(length(Distance)))+1));  
    %计算密度值，其中 Density 的每个元素是对应解的密度。密度的计算基于邻域的概念，
%这里采用最近的一定数量的解来计算密度。密度的计算公式为 1/(1 + d)，其中 d 是解到最近邻的距离。
 end
%这是一个用于计算多目标优化问题中解的密度的 MATLAB 函数。
%这个函数采用一个矩阵 PopObj 作为输入，其中每一行表示一个候选解的目标函数值。
%该函数返回一个列向量 Density，其中每个元素代表对应解的密度值。

%综合起来，这个函数的目的是通过计算解的相对距离，确定每个解在 Pareto 前沿上的密度。
%密度值越大，表示解越稀疏，即其周围的解相对较远。
