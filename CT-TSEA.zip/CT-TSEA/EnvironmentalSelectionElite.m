function [Feasible,Infeasible]= EnvironmentalSelectionElite(Population,N)%环境选择函数，输入参数包括种群Population和所需选择个体数量N。
      
      % remove duplicated solutions
      [~,b]=unique(Population.objs,'rows');
      Population = Population(1,b);%移除重复的解，保留唯一的解，并更新种群Population。
      
      [FrontNo,~] = NDSort([Population.objs,sum(max(0,Population.cons),2)],inf);%使用非支配排序函数NDSort对目标值矩阵与约束值矩阵进行非支配排序，得到每个个体所属的前沿编号FrontNo。

      % find the feasible soltuons and the corresponding indexes
      FeasibleIndex = sum(max(0,Population.cons),2)==0;    
      Feasible = Population(FeasibleIndex);
      FeasibleFrontNo = FrontNo(FeasibleIndex);
      Feasible = FeasibleUpdate(Feasible,FeasibleFrontNo,N); 
%找到可行解及其对应的索引。根据约束条件，将满足约束的个体筛选出来，并更新它们的前沿编号。
%使用FeasibleUpdate函数对筛选后的个体进行进一步处理，确保选择的个体数量不超过N。
      if length(Feasible)<N 
         N1 = N-length(Feasible);
         InfeasibleIndex = sum(max(0,Population.cons),2)~=0;
         Infeasible = Population(InfeasibleIndex); 
         [~,Index]=sort(sum(max(0,Infeasible.cons),2));
         Feasible=[Feasible,Infeasible(Index(1:N1))];
      end
   % 如果可行解的数量小于N，将选择一部分不满足约束条件但具有较低违反程度的个体作为补充。
   % 首先找到不满足约束的个体索引，然后根据违反程度对它们进行排序，并选择违反程度较低的个体加入到可行解集合中。  
 % find the infeasible solutions and the coresponding indexes
         InfeasibleIndex = sum(max(0,Population.cons),2)~=0;
         Infeasible = Population(InfeasibleIndex);
         InfeasibleFrontNo = FrontNo(InfeasibleIndex);
         Temp = InfeasibleFrontNo==1;
         Infeasible =Infeasible(Temp);
         InfeasibleFrontNo = InfeasibleFrontNo(Temp);
         Infeasible = InfeasibleUpdate(Infeasible,InfeasibleFrontNo, N );
end
%找到不可行解及其对应的索引。根据前沿编号，筛选出位于第一个前沿的不可行解，并更新它们的前沿编号。
%使用InfeasibleUpdate函数对筛选后的个体进行进一步处理，确保选择的个体数量不超过N。
%最终返回经环境选择得到的可行解集合Feasible和不可行解集合Infeasible。
function Population = FeasibleUpdate(Population,FrontNo,N)%可行解更新函数，输入参数包括种群Population、前沿编号FrontNo和所需选择个体数量N。

if length(Population)>N
  
    FrontNoSort = sort(FrontNo);
    MaxFNo = FrontNoSort(N);
    

    Next = FrontNo < MaxFNo;
    Population1 = Population(Next);
   
    Last = FrontNo == MaxFNo;
    Population2 = Population(Last);
    if sum(Last)~= N-sum(Next)
    Population2 = Truncation(Population2,Population,N-sum(Next));
    end
    Population = [Population1,Population2]; 
end
end
%如果可行解的数量大于N，则进行更新。首先根据前沿编号对FrontNo进行排序，并找到第N个前沿的编号MaxFNo。
%然后根据FrontNo判断哪些个体属于较低的前沿（Next），将它们放入Population1中。
%接着，将属于第N个前沿的个体（Last）放入Population2中，并根据需要使用Truncation函数对Population2进行修剪，
%确保选择的个体数量不超过N - sum(Next)。最后，将Population1和Population2合并成为更新后的种群Population。
function Population = InfeasibleUpdate(Population,FrontNo,N)
%不可行解更新函数，输入参数包括种群Population、前沿编号FrontNo和所需选择个体数量N
if length(Population) > N
    
    

 
    FrontNoSort = sort(FrontNo);
    MaxFNo = FrontNoSort(N);

    Next = FrontNo < MaxFNo;
    Population1 = Population(Next);
    

    Last = FrontNo == MaxFNo;
    Population2 = Population(Last);
    N1 = N- sum(Next); 
    %% Boudary sorting 
    [FrontNo1,MaxFNo1] = NDSort(-Population2.objs,N1);
   
    Next1 = FrontNo1 < MaxFNo1;
    Population3 = Population2(Next1);
    Last1 = FrontNo1==MaxFNo1;
    Population4 = Population(Last1);
   
    if sum(Last1)~= N1-sum(Next1)
    Population4 = Truncation(Population4,Population,N1-sum(Next1));
    end
    %% Population for next generation
    Population = [Population1,Population3,Population4];
end
    
end
%如果不可行解的数量大于N，则进行更新。首先根据前沿编号对FrontNo进行排序，并找到第N个前沿的编号MaxFNo。
%然后根据FrontNo判断哪些个体属于较低的前沿（Next），将它们放入Population1中。
%接着，将属于第N个前沿的个体（Last）放入Population2中。
%然后，计算需要额外选择的个体数量N1（N - sum(Next)）。
%接下来，使用NDSort函数对Population2的目标值取负并进行非支配排序，得到新的前沿编号FrontNo1和MaxFNo1。
%根据FrontNo1判断哪些个体属于较低的前沿（Next1），将它们放入Population3中。
%然后，将属于第N1个前沿的个体（Last1）放入Population4中，并根据需要使用Truncation函数对Population4进行修剪，
%确保选择的个体数量不超过N1 - sum(Next1)。最后，将Population1、Population3和Population4合并成为更新后的种群Population。



function Population = Truncation(Population,PopAll,N)%截断函数，通过截断选择部分解
% Select part of the solutions by truncation

    %% Truncation
    Zmin       = min(PopAll.objs,[],1);
    PopObjTemp = Population.objs;
    PopObj = (PopObjTemp -repmat(Zmin,length(Population),1))./(repmat(max(PopAll.objs),length(Population),1)-repmat(Zmin,length(Population),1));
 %计算归一化的目标值矩阵PopObj。首先找到PopAll中的最小目标值Zmin。
 %然后将Population的目标值减去Zmin并除以最大目标值与Zmin之间的差，得到归一化的PopObj。
    
    Distance = pdist2(PopObj,PopObj);
    Distance(logical(eye(length(Distance)))) = inf;
    Del = false(1,size(PopObj,1));
    while sum(Del) < size(PopObj,1)-N
        Remain   = find(~Del);
        Temp     = sort(Distance(Remain,Remain),2);
        [~,Rank] = sortrows(Temp);
        Del(Remain(Rank(1))) = true;
    end
    %计算解之间的距离矩阵Distance，并将对角线上的元素设为无穷大（排除自身与自身的距离）。
    %接下来，循环直到删除的解数量达到size(PopObj, 1) - N为止。
    %在每次循环中，找到未被删除的解的索引Remain，计算Remain之间的距离，并对其进行排序。
    %根据排序结果，选择距离最近的解并将其标记为删除（Del设为true）。
      Population = Population(Del==0);%根据删除标记Del，将没有被删除的解重新赋值给种群Population，以得到截断后的种群。
end