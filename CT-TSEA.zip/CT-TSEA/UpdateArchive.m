function UpdatedArchive=UpdateArchive(Archive,Population,N,Problem)
CV = sum(max(0, Population.cons), 2);
F = Population.objs;
  Archive = [Archive, Population(CV == 0)];
    if isempty(Archive)
        UpdatedArchive = Archive;
        return;
    end
if length(Archive) == N
    UpdatedArchive = Archive;
elseif length(Archive) <N
      FeasibleSet = Population(CV == 0);
   feasible_ratio = length(FeasibleSet) / length(Population);
W_cv = feasible_ratio;
W_f = 1- W_cv;
infeasible_idx = find(sum(Population.cons > 0, 2) > 0); 
potential_infeasible_solutions = [];
if ~isempty(infeasible_idx)
    scores = zeros(length(infeasible_idx), 1);
    for i = 1:length(infeasible_idx)
        idx = infeasible_idx(i);
        scores(i) = W_cv * CV(idx) + W_f * F(idx, 2);  
    end
    [~, sorted_idx] = sort(scores, 'ascend');

    if length(sorted_idx) <= length(infeasible_idx)
        selected_idx = infeasible_idx(sorted_idx);
    else
        selected_idx = infeasible_idx(sorted_idx(1:length(infeasible_idx)));
    end
    
    potential_infeasible_solutions = Population(selected_idx);
end

if isempty(Archive)
    Archive = SOLUTION.empty();  
end
for i = 1:length(selected_idx)
    infeasible_solution = potential_infeasible_solutions(i).objs; 
    feasible_objs = reshape([FeasibleSet.objs], [], size(infeasible_solution, 2));  
    distances = pdist2(infeasible_solution, feasible_objs);  
    [min_distance, min_idx] = min(distances(:));  
    nearest_feasible_solution = feasible_objs(min_idx, :);
    alpha = min_distance / max(pdist(feasible_objs(:))); 
    direction = (infeasible_solution - nearest_feasible_solution) / norm(infeasible_solution - nearest_feasible_solution);  
    new_solution_objs = nearest_feasible_solution + alpha * direction;  
    new_solution_objs = reshape(new_solution_objs, 1, []);  
    if ~isnumeric(new_solution_objs)
        error('new_solution_objs must be a numeric array');
    end
    example_decs = Population(1).decs;  
    new_solution_decs = example_decs;   
    new_individual = SOLUTION(new_solution_decs, new_solution_objs, zeros(1, size(Population(1).cons, 2)));  
    Archive = [Archive, new_individual]; 
end

 Fitness = CalFitness(Archive.objs, Archive.cons);
    Next = Fitness < 1;

    if sum(Next) < N
        [~, Rank] = sort(Fitness);
        Next(Rank(1:N)) = true;
    elseif sum(Next) > N
        Del = Truncation(Archive(Next).objs, sum(Next) - N);
        Temp = find(Next);
        Next(Temp(Del)) = false;
    end
 UpdatedArchive = Archive(Next);
 
else
    Fitness = CalFitness(Archive.objs, Archive.cons);
    Next = Fitness < 1;

    if sum(Next) < N
        [~, Rank] = sort(Fitness);
        Next(Rank(1:N)) = true;
    elseif sum(Next) > N
        Del = Truncation(Archive(Next).objs, sum(Next) - N);
        Temp = find(Next);
        Next(Temp(Del)) = false;
    end

    UpdatedArchive = Archive(Next);
end


end

function Del = Truncation(PopObj,K)
% Select part of the solutions by truncation

    %% Truncation
    Distance = pdist2(PopObj,PopObj);
    Distance(logical(eye(length(Distance)))) = inf;
    Del = false(1,size(PopObj,1));
    while sum(Del) < K
        Remain   = find(~Del);
        Temp     = sort(Distance(Remain,Remain),2);
        [~,Rank] = sortrows(Temp);
        Del(Remain(Rank(1))) = true;
    end
end